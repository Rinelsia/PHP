MVC 
Model View Controller

Page Controller - шаблон проектирования
пользователь делает запрос и его запрос обрабатывает один контроллер
на каждый запрос сущестует свой контроллер
это точки входа в приложение
если маленькое, то ок, если большое, то не удобно

Front Controller - одна точка входа
index обрабатывает запрос пользователя и обрабатывает инфрмацию, происходит выбор контроллера
исходя из запроса формирет контроллер
контроллер связывает модель и view 
такое приложение более правильное 

сессии хранятся в сервере в текстовом файле 

.htaccess для Apache
<IfModule mod_rewrite.c>
    RewriteEngin On
    
    RewriteCond %{REQUEST_FILENAME}% !-f
    RewriteCond %{REQUEST_FILENAME}% !-d
    
    RewriteRule ^(.*)$ index.php [L, QSA]
</IfModule>

