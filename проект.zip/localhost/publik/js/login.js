$(document).ready(function(){
    function authUser (){
        event.preventDefault();
        var login = jQuery('#login').val();
        var pwd = jQuery('#pwd').val();
        jQuery.ajax({
            type: 'post',
            url: '/login',
            data: {
                login: login,
                pwd:pwd
            },
            success: function(resp){
                console.log(resp);
                if (resp === "ok"){
                    // как переключиться на другую страничку силами js
                    document.location.href='/';
                }
            },
            error: function (resp){
                console.log(resp);
            }
        })
    }
    jQuery('#autform').submit(authUser);
});