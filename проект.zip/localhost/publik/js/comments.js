//так всегда оборачивается jQuery
$(document).ready(function() {
    console.log("Comment.js");
    
    $('#comment_form').submit(function(event) {
        event.preventDefault();
        var comment = document.getElementById("comment").value; //получаем текст из textarea
        $.ajax({
            type: 'post',
            url: '/addComment', //этот запрос обрабатывается в контроллере
            data: { comment: comment }, //данные, которые хотим передать, передаем в виде объекта 
            //если установлено соединение, то сервер вернет success
            success: function(resp) {
                console.log(resp);
            },
            error: function(resp) {
                console.log(resp);
            }
       });     
    });
});
//console.log("пишем ajax-запрос");
//можно писать через http-request