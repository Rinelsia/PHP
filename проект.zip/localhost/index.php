<?php 

// //.htaccess - для Apache

// require_once __DIR__ . '/app/core/router.php';
// // подключаем модели
// require_once __DIR__ . '/app/models/goods_model.php';
// require_once __DIR__ . '/app/models/auth_model.php';

// //здесь же подключаем контроллеры 
// require_once __DIR__ . '/app/controllers/controllers.php';

// //запускаем функцию обработки контроллеров в соответствии с запросами
// //здесь получаем запрос пользователя 
// //работаем со строкой из запроса 
// function runController() {
//     //распарсим url 
//     //всю информацию моем получить из $_SERVER
//     $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
// //    var_dump($uri); // '/index.php' 
// //    var_dump($_SERVER['REQUEST_URI']);
//     $action = trim($uri, "/") ? : "index";  //addComment
//     $action = $action . "Action";           //addCommentAction
// //    var_dump($action);
    
//     if (!function_exists($action)) {
//         header($_SERVER["SERVER_PROTOCOL"] . "404 Not Found");
//         exit("404 Not Found");
//     }
    
//     $action();  // вызов функции, она будет написана в контроллере  //addCommentAction()
// }

// session_start();
// runController();

require_once __DIR__.'/vendor/autoload.php';
session_start();

$routes = file_get_contents('urls.json');// файл json

$app = new \Sky\Frame\App($routes);
var_dump($app); 
$app->run();

?>