<?php
	

	class Router{
		public static $instance;
		public static function getinstance(){
		if(!(self::$instance instanceof self))	{
			self::$instance = new self();
		}
		return self::$instance;
		}

		protected $controller;
		protected $action;
		protected $params;

		private function __construct()
		{
			$uri = $_SERVER['REQUEST_URI'];
			var_dump($uri);
			$uri_parts = explode('/', trim($uri, '/'));
			var_dump($uri_parts);

			$this->controller = !empty($uri_parts[0])?ucfirst($uri_parts[0]).'controller':'IndexController';
			//всего Router
			var_dump($this->controller);
			// $this->params = trim($uri_parts[2], '?');
			$params_arr = explode('=', trim($uri_parts[2], '?'));
			$len = count($params_arr);
			for ($i=0; $i < $len ; $i++) { 
				if ($i%2==0){
					$this->params = [$params_arr[i]=>$params_arr[$i+1]];
					var_dump($this->params);
				}
			}


			$params_uri = parse_url($uri, PHP_URL_QUERY);
			var_dump($params_uri);
			parse_str($params_uri, $arr);
			var_dump(parse_str($params_uri, $arr));
			$this->params = $arr;
			
		}

		public function run (){

				if (class_exists(class_name)) {
					if (method_exists($this->getController(), $this->getAction())){
						$controllerName=$this->getController();
						$actionName = $this->getAction();
						$var = new $controllerName();
						$var->$actionName();
					} else{
						throw new Exception("Нет метода", 1);
						
					}
				}else {
						throw new Exception("Нету контролера", 1);
						
					}
				
			 function getController()
			{
						return $this->controller;
					}
					 function getAction (){
						return $this->action;
					}


	}
	// композер узнать установитьы
?>
// после установки композера, надо установить php composer.phar require simfiny/routing писать в консоле
// require symfony/routing
// require symfony/http-kernel
//require symfony/http-foundation