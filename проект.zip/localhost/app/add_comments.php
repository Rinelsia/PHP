<?php

//обрабатываем форму 
if ($_POST['tst'] == 'tst') {
    echo "ok";
} else {
    echo "not ok";
}


?>