<?php 

//описываем контроллеры - связывание модели и представления 
// "/index"
// function indexAction() {
//     // echo "INDEX";   
//     //session_start();
//     logout();
//     generateView("all_goods_view.php", "template.php", [
//         "goods_data" => getAllGoods(),
//         "auth" => is_session(),
//     ]);
// }

// "/description"
// function descriptionAction() {
//     // echo "DESCRIPTION";
//     //session_start();
//     logout();
//     $good = getGoodById(isset($_GET["id"]) ? $_GET["id"] : "");
    
//     //генерит html с описанием одного товара 
//     generateView("good_info_view.php", "template.php", [
//         //"current_good" => getGoodById(),
//         "current_good" => $good,
//         "auth" => is_session(),
//     ]);
// }

// "/login"
function loginAction() {
    //echo "LOGIN";
    
    //session_start();
    logout();
    $login = (isset($_POST["login"]) ? $_POST["login"] : "");
    $pwd = (isset($_POST["pwd"]) ? $_POST["pwd"] : "");
    
    // сделать дома личный кабинет пользователю 
    if (login($login, $pwd) || is_session()) {
        header("Location: /");
//        generateView("auth_form.php", "template.php");
    } else{
        generateView("auth_form.php", "template.php");
    }
    
    
}

//сервер должен обработать комментарий 
function addCommentAction() {
    //получение данных 
    $comment = $_POST['comment'];
    echo $comment;
}


// передаем имя шаблона и имя файла
// function generateView($contentView, $template, $data=[]) {
    
//     if(is_array($data)) {
//         extract($data);
//     }
//     require_once "app/views/" . $template;
// }

?>