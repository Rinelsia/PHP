<?php
namespace Course\Shop\controllers;

require_once __DIR__.'app/models/goods_model.php'
class GoodsController {

	public function indexAction(){
		generateView("all_goods_view.php", "template.php", [
        "goods_data" => getAllGoods(),
        "auth" => is_session(),
    ]);
	}
	public function descriptionAction($id){

		$comments = getAllComments();
		$good = getGoodById(isset($id) ? $id : '');
    
    	//генерит html с описанием одного товара 

    	generateView("good_info_view.php", "template.php", [
        // "current_good" => getGoodById(),
        'app_tittle'=>$good['title']
        "current_good" => $good,
        'comments'=>$comments,
        "auth" => false,
	}
}
function generateView($contentView, $template, $data=[]) {
    
    if(is_array($data)) {
        extract($data);
    }
    require_once "app/views/" . $template;
}
//modells
function getGoodsFromFile() {
    // 'r' - Открывает файл только для чтения; помещает указатель в начало файла.
    // fread - читает до length байт из файлового указателя handle и смещает указатель. 
    $fp = fopen('app/models/goods_data.txt', 'r');
    if($fp) {
        while (($data = fread($fp, 4096)) !== false) {
            return $data;
        }
        fclose($fp);
    }
    return false;
}

?>