<?php
	class IndexController{
		function indexAction{
			echo "indexAction";
		}
	}
?>