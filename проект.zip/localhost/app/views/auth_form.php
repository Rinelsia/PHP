
<form method="post" action="/login">
    <label for="login">Логин</label>
    <input name="login" id="login" type="text">

    <label for="pwd">Пароль</label>
    <input name="pwd" id="pwd" type="password">

    <label for="check">Запомнить</label>;
    <input name="check" id="check" type="checkbox">

    <button id="sbm" type="submit">Войти</button>
</form>

