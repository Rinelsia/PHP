<!DOCTYPE HTML>
<html lang="ru">
<head>
    <title>Главная</title>
    <meta charset="utf-8"> 
    <script src="../../publik/js/jquery-3.1.1.min.js"></script>
    <script src="../../publik/js/comment.js"></script>
</head>
<body>
    <!-- menu -->
    <ul>
        <li><a href="/"> Главная </a></li>
        
        
        <?php if ($auth): ?>
            <li><a href="?exit=exit"> Выйти </a></li>
            <li><a href="/">Личный кабинет</a></li>
        <?php else: ?>
           
            <li><a href="/login"> Войти </a></li>
        <?php endif; ?>
        
    </ul>
    
    <?php include $contentView; ?> 
    
    
   
</body>
</html>