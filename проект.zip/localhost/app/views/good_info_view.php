<div>
    <!-- название -->
    <h1> <?php echo $current_good['title']; ?> </h1>

    <!-- описание -->
    <p> <?php echo $current_good['description']; ?> </p> 
</div>
    
<!--зареган-->
<?php 
var_dump($auth);
    if ($auth): 
?>
<form action="/addComment" id="comment_form">
    <textarea name="comment" id="comment" cols="30" rows="10" title="Комментарий" placeholder="Комментарий"></textarea>
    <button type="submit"> Оставить комментарий </button>
</form>

<!--не зарегистрирован-->
<?php else: ?>
    <p> Вы не можете оставлять комментарии </p>
<?php endif; ?>

<script src="../../publik/js/comments.js"></script>